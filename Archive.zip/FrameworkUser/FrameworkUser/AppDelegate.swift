//
//  AppDelegate.swift
//  FrameworkUser
//
//  Created by Khan, Mohsin on 07/03/22.
//

import UIKit
import dy_fw

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    var movieSearchCoordinator: MovieSearchCoordinator?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
            
        window = UIWindow(frame: UIScreen.main.bounds)
        let navVC = UINavigationController()
        window?.rootViewController = navVC
        movieSearchCoordinator = MovieSearchCoordinator(navigationController: navVC, data: nil)
        window?.makeKeyAndVisible()
        movieSearchCoordinator?.start()
        
        return true
    }
}

