//
//  FirstCoordinator.swift
//  MovieWatch
//
//  Created by Khan, Mohsin on 01/03/22.
//

import Foundation
import UIKit

public class MovieSearchCoordinator: Coordinator {
    public var data: AnyObject?
    public var childCoordinators: [Coordinator] = []
    unowned let navigationController: UINavigationController
    
    required public init(navigationController: UINavigationController, data: AnyObject?) {
        self.navigationController = navigationController
        self.data = data
    }
    
    @discardableResult
    public func start() -> Bool {
        print("Starting search coordinator flow")
        if let _vc = MovieSearchViewController.instantiate() {
            print("\(_vc) found!")
            _vc.navDelegate = self
            navigationController.viewControllers = [_vc]
            return true
        }
        return false
    }
}
extension MovieSearchCoordinator: MovieSearchDelegate {
    func navigateToMovieDetails(viewModel: MovieViewModelOutput?) {
        let movieDetailsCoordinator = MovieDetailsCoordnator(navigationController: navigationController, data: viewModel)
        movieDetailsCoordinator.delegate = self
        childCoordinators.append(movieDetailsCoordinator)
        movieDetailsCoordinator.start()
    }
}
extension MovieSearchCoordinator: BackToMovieSearchDelegate {
    func navigateBackToMovieSearch(coordinator: MovieDetailsCoordnator) {
        navigationController.popToRootViewController(animated: true)
        childCoordinators.removeLast()
    }
}
