//
//  Enums.swift
//  MovieWatch
//
//  Created by Khan, Mohsin on 02/03/22.
//

import Foundation

enum MovieSearchCategories: String, CaseIterable {
    case years = "Years"
    case genres = "Genres"
    case directors = "Directors"
    case actors = "Actors"
    case allMovies = "All Movies"
}

enum SortCriteria: String, CaseIterable {
    case yearNewToOld = "Year(New to Old)"
    case yearOldToNew = "Year(Old to New)"
}
enum DateFormat: String {
    case dd_MMM_yyyy = "dd MMM yyyy"
    case yyyyMMdd = "yyyyMMdd"
}
